package android.support.v4.net;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import org.jraf.android.backport.switchwidget.C0678R;

class ConnectivityManagerCompatGingerbread {
    ConnectivityManagerCompatGingerbread() {
    }

    public static boolean isActiveNetworkMetered(ConnectivityManager cm) {
        NetworkInfo info = cm.getActiveNetworkInfo();
        if (info == null) {
            return true;
        }
        switch (info.getType()) {
            case C0678R.styleable.Switch_asb_thumb /*0*/:
            case C0678R.styleable.Switch_asb_textOn /*2*/:
            case C0678R.styleable.Switch_asb_textOff /*3*/:
            case C0678R.styleable.Switch_asb_thumbTextPadding /*4*/:
            case C0678R.styleable.Switch_asb_switchTextAppearance /*5*/:
            case C0678R.styleable.Switch_asb_switchMinWidth /*6*/:
                return true;
            case C0678R.styleable.Switch_asb_track /*1*/:
                return false;
            default:
                return true;
        }
    }
}
